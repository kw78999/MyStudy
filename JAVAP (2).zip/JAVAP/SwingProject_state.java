package JAVAP;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

//�̿���Ȳ
public class SwingProject_state {
	static String col[] = {"�����ȣ","ȸ����ȣ","ȸ�� �̸�","���� ��ȣ","���� �̸�","���� ��¥","�ݳ� ��¥"};
	static String row1 [][];
	JPanel npanel = new JPanel();
	static JPanel mpanel = new JPanel();
	static JPanel tpanel = new JPanel();
	JPanel cpanel = new JPanel();
	
	static JTable table;                             //���̺��� �ʿ��� Ŭ����
	static DefaultTableModel model;
	static JScrollPane scr;
	static DefaultTableModel m;
	
	Choice cho = new Choice();
	JTextField tf = new JTextField(10);
	JButton btn = new JButton("�˻�");
	
	
	static  BrentalMgr  mgr= new BrentalMgr();
	 static    Vector <BrentalBean>  vlist ;
	
	
	public static void viewstate() {
		vlist = mgr.getListBRental();
		row1 = new String [vlist.size()][7];
		for (int i = 0; i < row1.length; i++) {
			BrentalBean bean = vlist.elementAt(i);
			row1[i][0] = bean.getRID()+"";
			row1[i][1] = bean.getRMID()+"";
			row1[i][2] = bean.getRNAME();
			row1[i][3] = bean.getBMID()+"";
			row1[i][4] = bean.getBTITLE();
			row1[i][5] = bean.getRENTAL().substring(0, 10);  //��¥ �ϱ����� ���̰��ϱ� 
			row1[i][6] = bean.getENDRENTAL().substring(0, 10);
		}
		model = new DefaultTableModel(row1,col);   //�߰� ���� ������ ������ DefaultTableModel ����
		table = new JTable(model);         //���̺��� ���̺��� ������
		scr = new JScrollPane(table); 	//��ũ�� ����
		 table.getColumnModel().getColumn(0).setPreferredWidth(90);  //JTable �� �÷� ���� ����
		    table.getColumnModel().getColumn(1).setPreferredWidth(90);
		    table.getColumnModel().getColumn(2).setPreferredWidth(110);
		    table.getColumnModel().getColumn(3).setPreferredWidth(90);
		    table.getColumnModel().getColumn(4).setPreferredWidth(400);
		    table.getColumnModel().getColumn(5).setPreferredWidth(200);
		    table.getColumnModel().getColumn(6).setPreferredWidth(200);
		    table.setFont(new Font( "Times", Font.BOLD, 20) );
		    table.setRowHeight(30);
		   // table.enable(false);
		    scr.setBounds(0, 0, 1175, 300);
		    tpanel.add(scr);
		
	}
	
         public SwingProject_state() {
        	 viewstate();
        	 mpanel.setBackground(new  Color(170,220,255));
        	 npanel.setBackground(new  Color(170,220,255));
        	 cpanel.setBackground(new Color(170,220,255));
        	 tpanel.setBackground(new Color(170,220,255));
             npanel.setLayout(null);
             mpanel.setLayout(null);
             tpanel.setLayout(null);
             
         	TitledBorder jtx=          //�˻�â ����
    	    		new TitledBorder(new LineBorder(Color.white),"�˻�");
    		 jtx.setTitleFont(new Font( "Times", Font.BOLD, 18 ) );
    	     
          	TitledBorder jtx1=          //�˻�â ����
     	    		new TitledBorder(new LineBorder(Color.white),"ȸ������ ä��");
     		 jtx1.setTitleFont(new Font( "Times", Font.BOLD, 18 ) );
     		 cpanel.setBorder(jtx1);
     		 
    		 cho.add("���� ��ȣ");
    		 cho.add("ȸ�� ��ȣ");
    		 cho.add("���� ��ȣ");
    		 cho.setBounds(250, 50, 150, 50);
    		 tf.setBounds(430,50 , 150, 27);
    	
    		 
    		 btn.setBounds(580, 50, 100, 27);
    	     btn.addActionListener(ac);
    	 cpanel.setBounds(600, 430, 570,260);
    	 tpanel.setBounds(0, 120, 1175, 300);
    	 npanel.add(tf);
    	 npanel.add(btn);
    	 npanel.add(cho);
    	 npanel.setBounds(0, 0, 1200, 120);
    	 scr.setBounds(0, 0, 1175, 300);
    	 npanel.setBorder(jtx);
    	 mpanel.add(npanel);
    	 mpanel.add(cpanel);
    	 mpanel.add(tpanel);
    	 npanel.setPreferredSize(new Dimension(1200,120));	 
            	 
          }
         
         ActionListener ac = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(cho.getSelectedIndex()==0) {
					int BID = Integer.parseInt(tf.getText());
					
					String row1[][] = new String [1][7];
					for (int i = 0; i < row1.length; i++) {
						BrentalBean bean = mgr.getett(BID);
						row1[i][0] = bean.getRID()+"";
						row1[i][1] = bean.getRMID()+"";
						row1[i][2] = bean.getRNAME();
						row1[i][3] = bean.getBMID()+"";
						row1[i][4] = bean.getBTITLE();
						row1[i][5] = bean.getRENTAL();
						row1[i][6] = bean.getENDRENTAL();
					}
					model = new DefaultTableModel(row1,col);   //�߰� ���� ������ ������ DefaultTableModel ����
					table = new JTable(model);         //���̺��� ���̺��� ������
					scr = new JScrollPane(table); 	//��ũ�� ����
					 table.getColumnModel().getColumn(0).setPreferredWidth(90);  //JTable �� �÷� ���� ����
					    table.getColumnModel().getColumn(1).setPreferredWidth(90);
					    table.getColumnModel().getColumn(2).setPreferredWidth(110);
					    table.getColumnModel().getColumn(3).setPreferredWidth(90);
					    table.getColumnModel().getColumn(4).setPreferredWidth(400);
					    table.getColumnModel().getColumn(5).setPreferredWidth(200);
					    table.getColumnModel().getColumn(6).setPreferredWidth(200);
					    table.setFont(new Font( "Times", Font.BOLD, 20) );
					    table.setRowHeight(30);
					    scr.setBounds(0, 0, 1175, 300);
					tpanel.removeAll();
					tpanel.revalidate();
					vlist.removeAllElements();
					 tpanel.add(scr);
					 if(table.getValueAt(0, 0).equals("0")) {
						 MDialog md = new MDialog(SwingProject.frame,	"����", true,"�˻������� �����ϴ�.");
					md.setVisible(true);
					 }
				}
				
				
				
				
			}
		};
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
}
