package JAVAP.copy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Main {	
	private static Connection conn;
	private static PreparedStatement pstmt;

	public static void main(String[] args) {
		try {
			//conn = DriverManager.getConnection("JOON//localhost:1521/xe","joon","1234");
			pstmt = conn.prepareStatement("insert into BMEMBERS values(MID,MNAME,MPHONE,MGRADE,MAXRENTAL,ECOUNT,ECOUNTP,ELIMIT)");
			pstmt.setString(1, "4");
			pstmt.setString(2, "�����");
			pstmt.setString(3, "010-1010-1010");
			pstmt.setString(4, "VIP");
			pstmt.setString(5, "7");
			pstmt.setString(6, "15");
			pstmt.setString(7, "19");
			pstmt.setString(8, "7");

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}