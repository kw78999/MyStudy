package JAVAP;

public class SwingProject_rental {

}
