package JAVAP;

import java.awt.Color;

public class BookThread2  implements Runnable{

	
	static Color red = new Color(255,184,249);   
	
	
	
	@Override
	public void run() {
	try {
		int l = 249 ;
		int j = 184;
		
		for (int i = 255; j<255; j++) {  //���ٲٸ鼭 ��� ���������ϱ� 
			
			SwingProject_1.tf6.setBackground(new Color(i,j,l));
			
			
			Thread.sleep(20);
			if(l<255)
				l++;
		}
		}catch(Exception e){
			
		}

}}
