package JAVAP;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;


public class ChartFrame extends JPanel{
	ImageIcon normalIcon5 = new ImageIcon("C:\\\\\\\\image\\\\send.jpg"); 
	ImageIcon normalIcon6 = new ImageIcon("C:\\\\\\\\image\\\\sned3.jpg"); 
	 static  JButton sbtn ;
	 Image btnimg5 = normalIcon5.getImage(); 
	 Image btnimg6= normalIcon6.getImage(); 
	 //��ư�� �̹��� �߰�
	  Image change5 = btnimg5.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
	  ImageIcon changeicon5 = new ImageIcon(change5);
	  
	  Image change6 = btnimg5.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
	  ImageIcon changeicon6= new ImageIcon(change6);
	  
	  Image change7 = btnimg6.getScaledInstance(40, 40, Image.SCALE_SMOOTH);
	  ImageIcon changeicon7= new ImageIcon(change7);
	  ///////////////////////////////////////////////////////////////////
	  ImageIcon normalIcon1 = new ImageIcon("C:\\\\\\\\image\\\\do.jpg"); 
		ImageIcon normalIcon2 = new ImageIcon("C:\\\\\\\\image\\\\do2.jpg"); 
		 static  JButton dobtn ;
		 Image btnimg1 = normalIcon1.getImage(); 
		 Image btnimg2= normalIcon2.getImage(); 
		 //��ư�� �̹��� �߰�
		  Image change1 = btnimg1.getScaledInstance(90, 45, Image.SCALE_SMOOTH);
		  ImageIcon changeicon1 = new ImageIcon(change1);
		  
		  Image change2 = btnimg1.getScaledInstance(100, 50, Image.SCALE_SMOOTH);
		  ImageIcon changeicon2= new ImageIcon(change2);
		  
		  Image change3 = btnimg2.getScaledInstance(90, 45, Image.SCALE_SMOOTH);
		  ImageIcon changeicon3= new ImageIcon(change3);
		  ///////////////////////////////////////////////////////////////////
	static String s1;
	static String s2;
	
	String year[] = {"20��", "19��"};
	String month[] = {"12��","11��","10��","09��","08��","07��","06��","05��","04��","03��","02��","01��"};
	JComboBox<String> cbYear = new JComboBox<String>(year);
	JComboBox<String> cbMonth = new JComboBox<String>(month);
	
	
	
	
	JPanel southPanel = new JPanel();
	static JPanel northPanel = new JPanel();
	ChartPanel01 p1 = new ChartPanel01();
	ChartPanel02 p2 = new ChartPanel02();
	ChartPanel03 p3 = new ChartPanel03();
	static JPanel p4 = new JPanel();
	Color cor = new Color(186,218,255);
	
	static JTextField ctf = new JTextField("",50);
	static JTextArea cta = new JTextArea();
	static JScrollPane chatScroll ;
	static Color bg = new Color(186,218,255);
	

//	Container c;
	
	public ChartFrame(){
		dobtn = new JButton(changeicon1);
		dobtn.addMouseListener(dob);
		northPanel.setBounds(0,0,1200, 50);
		northPanel.setLayout(null);
		northPanel.setBackground(cor);
		dobtn.setBounds(250, 0, 100, 50);
		northPanel.add(dobtn);
		dobtn.addActionListener(CallXl);
		
		cbYear.setBounds(15, 15, 100, 20);
		cbMonth.setBounds(125, 15, 100, 20);
		northPanel.add(cbMonth);
		northPanel.add(cbYear);
		cbMonth.addItemListener(repaintChart);
		
		southPanel.setBounds(0,50,1200, 700);
		southPanel.setLayout(null);
		southPanel.setBackground(cor);
		//setTitle("Grid");
	//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1200, 700);
	//	setLocationRelativeTo(null);
	//	GridLayout grid = new GridLayout(2, 2);
	//	Container c = getContentPane();
      setLayout(null);
		TitledBorder tB1 = new TitledBorder(new LineBorder(Color.LIGHT_GRAY, 1, true),"������");
		tB1.setTitleFont(new Font("��Ǯ���¿��� Medium", Font.PLAIN, 15));
		p1 = new ChartPanel01();
		p1.setLayout(null);
		
		p2 = new ChartPanel02();
		p2.setLayout(null);
		
		p3 = new ChartPanel03();
		p3.setLayout(null);
		
		p4.setLayout(null);
		TitledBorder jtx1=          //�˻�â ����
 	    		new TitledBorder(new LineBorder(Color.white,5),"ȸ������ ä��");
 		 jtx1.setTitleFont(new Font(  "��Ǯ���¿��� Medium", Font.PLAIN, 18) );
 		 p4.setBorder(jtx1);
 		chatScroll = new JScrollPane(cta);
	ChatAction ca = new ChatAction();
		cta.setEnabled(false);
		 cta.setDisabledTextColor(Color.black);
		  cta.setBackground(Color.white);
		  sbtn = new JButton(changeicon5);
		  sbtn.setBorderPainted(false);			
			sbtn.setFocusPainted(false);
			sbtn.setContentAreaFilled(false);
			  dobtn.setBorderPainted(false);			
				dobtn.setFocusPainted(false);
				dobtn.setContentAreaFilled(false);
		  sbtn.addActionListener(ca.acc);
		  ctf.addActionListener(ca.acc);
		  sbtn.setBounds(470, 220, 80,30);
		  sbtn.addMouseListener(se);
		  ctf.setBounds(20, 220, 450, 30);
		  chatScroll.setBounds(20,30	, 530, 190);
		  chatScroll.setBackground(bg);
		  p4.add(sbtn);
		  p4.add(ctf);
		  p4.add(chatScroll);
		 p1.setBackground(bg);
	     p2.setBackground(bg);
         p3.setBackground(bg);
	   	p4.setBackground(cor);
		setBackground(cor);
		southPanel.add(p1);
		p1.setBounds(0, 0, 600, 350);
		p2.setBounds(600, 0, 600, 350);
		p3.setBounds(0, 350, 600, 350);
		southPanel.add(p2);
		southPanel.add(p3);
		southPanel.add(p4);
		p4.setBounds(602, 420, 570, 260);
		add(northPanel);
		add(southPanel);
		
		
		
		
		
		
		setVisible(true);
	}
	
	ActionListener CallXl = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			new ExcelFrame();
		}
	};
	
	ItemListener repaintChart = new ItemListener() {
		
		@Override
		public void itemStateChanged(ItemEvent e) {
			s1 = (String) cbMonth.getSelectedItem();
			s2 = (String) cbYear.getSelectedItem();
//			new ChartPanel02(s1,s2);
			
			repaint();			
		}
		
	};
	MouseListener se = new MouseListener() {
		
		@Override
		public void mouseReleased(MouseEvent e) {
			sbtn.setIcon(changeicon6);
		}
		@Override
		public void mousePressed(MouseEvent e) {
			sbtn.setIcon(changeicon7);
		}
		@Override
		public void mouseExited(MouseEvent e) {
			sbtn.setIcon(changeicon5);
		}
		@Override
		public void mouseEntered(MouseEvent e) {
			sbtn.setIcon(changeicon6);
		}
		@Override
		public void mouseClicked(MouseEvent e) {
		}
	}; 
MouseListener dob = new MouseListener() {
		
		@Override
		public void mouseReleased(MouseEvent e) {
			dobtn.setIcon(changeicon2);
		}
		@Override
		public void mousePressed(MouseEvent e) {
			dobtn.setIcon(changeicon3);
		}
		@Override
		public void mouseExited(MouseEvent e) {
			dobtn.setIcon(changeicon1);
		}
		@Override
		public void mouseEntered(MouseEvent e) {
			dobtn.setIcon(changeicon2);
		}
		@Override
		public void mouseClicked(MouseEvent e) {
		}
	}; 
//		@Override
//		public void actionPerformed(ActionEvent e) {
//			System.out.println("��Ʈ 123 ������Ʈ �޼ҵ� ȣ���ϱ�");
//			s1 = (String) cbMonth.getSelectedItem();
//			s2 = (String) cbYear.getSelectedItem();
//			System.out.println("��Ʈ�������Դϴ�"+s1+s2);
////			new ChartPanel02(s1,s2);
//			
//			repaint();
//		}
//	};
	
//	
//	public static void main(String[] args) {
//		new ChartFrame();
//	}
}
