package JAVAP;

import java.awt.Color;

import JAVAP.SwingProject_1.SwingProject1_newf;

public class BookThread4 implements Runnable{

	
	static Color red = new Color(255,184,249);   
	
	
	
	@Override
	public void run() {
	try {
		int l = 249 ;
		int j = 184;
		
		for (int i = 255; j<255; j++) {  //���ٲٸ鼭 ��� ���������ϱ� 
			if(SwingProject1_newf.tf22.getText().equals("")) {
				SwingProject1_newf.tf22.setBackground(new Color(i,j,l));
			}else if(SwingProject1_newf.tf20.getText().equals("")){
				SwingProject1_newf.tf20.setBackground(new Color(i,j,l));
				}else if(asdff.tfTitle.getText().equals("")) {
				asdff.tfTitle.setBackground(new Color(i,j,l));
				
	     	}else if(asdff.tfAuthor.getText().equals("")) {
	     		asdff.tfAuthor.setBackground(new Color(i,j,l));
		    }
			
			
			Thread.sleep(20);
			if(l<255)
				l++;
		}
	}catch(Exception e){
			
		}

}}