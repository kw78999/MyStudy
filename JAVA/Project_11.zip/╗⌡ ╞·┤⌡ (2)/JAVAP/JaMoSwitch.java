package JAVAP;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JTextField;

import JAVAP.SwingProject_1.SwingProject1_newf;

public class JaMoSwitch {
	//������ ù ������ ������ �߶� ���̴�. �� = ��
	public static String direct3(String bTitle){
        char b =bTitle.charAt(0);
        String chosung = null;
        int first = (b - 44032 ) / ( 21 * 28 );
         switch(first){
             case 0:
            	 chosung="��";
                 break;
             case 1:
                 chosung="��";
                 break;
             case 2:
                 chosung="��";
                 break;
             case 3:
            	 chosung="��";
                 break;
             case 4:
                 chosung="��";
                 break;
             case 5:
                 chosung="��";
                 break;
             case 6:
                 chosung="��";
                 break;
             case 7:
            	 chosung="��";
                 break;
             case 8:
                 chosung="��";
                 break;
             case 9:
            	 chosung="��";
                 break;
             case 10:
                 chosung="��";
                 break;
             case 11:
                 chosung="��";
                 break;
             case 12:
            	 chosung="��";
                 break;
             case 13:
                 chosung="��";
                 break;
             case 14:
                 chosung="��";
                 break;
             case 15:
                 chosung="��";
                 break;
             case 16:
                 chosung="��";
                 break;
             case 17:
                 chosung="��";
                 break;
             case 18:
                 chosung="��";
                 break;
         }     
      return chosung;
 }

	//���ڸ� �Է¹޾� �ʼ��� ������ ������ȣ�� �´� ���ڷ� ��ȯ���ִ� �޼ҵ�
	public static String direct(String author){
        char b =author.charAt(1);
        String chosung = null;
        String chosungToNum = null;
        int first = (b - 44032 ) / ( 21 * 28 );
         switch(first){
             case 0:
            	 chosung="��";
            	 chosungToNum="1";
                 break;
             case 1:
                 chosung="��";
                 chosungToNum="1";
                 break;
             case 2:
                 chosung="��";
                 chosungToNum="19";
                 break;
             case 3:
            	 chosung="��";
            	 chosungToNum="2";
                 break;
             case 4:
                 chosung="��";
                 chosungToNum="2";
                 break;
             case 5:
                 chosung="��";
                 chosungToNum="29";
                 break;
             case 6:
                 chosung="��";
                 chosungToNum="3";
                 break;
             case 7:
            	 chosung="��";
            	 chosungToNum="4";
                 break;
             case 8:
                 chosung="��";
                 chosungToNum="4";
                 break;
             case 9:
            	 chosung="��";
            	 chosungToNum="5";
                 break;
             case 10:
                 chosung="��";
                 chosungToNum="5";
                 break;
             case 11:
                 chosung="��";
                 chosungToNum="6";
                 break;
             case 12:
            	 chosung="��";
            	 chosungToNum="7";
                 break;
             case 13:
                 chosung="��";
                 chosungToNum="7";
                 break;
             case 14:
                 chosung="��";
                 chosungToNum="8";
                 break;
             case 15:
                 chosung="��";
                 chosungToNum="87";
                 break;
             case 16:
                 chosung="��";
                 chosungToNum="88";
                 break;
             case 17:
                 chosung="��";
                 chosungToNum="89";
                 break;
             case 18:
                 chosung="��";
                 chosungToNum="9";
                 break;
         }     
//      return chosung;
      return chosungToNum;
 }
	//������ ������ ������ȣ�� �´� ���ڷ� ��ȯ���ִ� �޼ҵ�
	public static String direct2(String author){
        char b =author.charAt(1);
        String js = null;
        String jsToNum = null;
        int first = (b - 44032 ) % ( 21 * 28 ) / 28;
         switch(first){
             case 0:
            	 js="��";
            	 jsToNum="2";
                 break;
             case 1:
                 js="��";
                 jsToNum="3";
                 break;
             case 2:
                 js="��";
                 jsToNum="3";
                 break;
             case 3:
            	 js="��";
            	 jsToNum="3";
                 break;
             case 4:
                 js="��";
                 jsToNum="4";
                 break;
             case 5:
                 js="��";
                 jsToNum="4";
                 break;
             case 6:
                 js="��";
                 jsToNum="4";
                 break;
             case 7:
            	 js="��";
            	 jsToNum="4";
                 break;
             case 8:
                 js="��";
                 jsToNum="5";
                 break;
             case 9:
            	 js="��";
            	 jsToNum="5";
                 break;
             case 10:
                 js="��";
                 jsToNum="5";
                 break;
             case 11:
                 js="��";
                 jsToNum="5";
                 break;
             case 12:
            	 js="��";
            	 jsToNum="5";
                 break;
             case 13:
                 js="��";
                 jsToNum="6";
                 break;
             case 14:
                 js="��";
                 jsToNum="6";
                 break;
             case 15:
                 js="��";
                 jsToNum="6";
                 break;
             case 16:
                 js="��";
                 jsToNum="6";
                 break;
             case 17:
                 js="��";
                 jsToNum="6";
                 break;
             case 18:
                 js="��";
                 jsToNum="7";
                 break;
             case 19:
                 js="��";
                 jsToNum="7";
                 break;
             case 20:
                 js="��";
                 jsToNum="8";
                 break;
         }     
//      return js;
      return jsToNum;
 }
	public static String firstName(String author) {
		String s = author;
		String subs = s.substring(0, 1);
		return subs;
	}
	
	public static void getTxt(String title, String author) {
		SwingProject1_newf.tf20.setText(firstName(author)+direct(author)+direct2(author)+direct3(title));
	}
	
	public JaMoSwitch() {
		
		JFrame frame = new JFrame();
		JTextField tf = new JTextField();
		
		tf.setSize(120,40);
		tf.setBackground(Color.CYAN);
		frame.add(tf);
		
		frame.setSize(120, 100);
		frame.setVisible(true);
		
		System.out.println(firstName("������"));
		System.out.println(direct("������"));
		System.out.println(direct2("������"));
	}
	
	
	
	public static void main(String[] args) {
;		new JaMoSwitch();
	}

}
