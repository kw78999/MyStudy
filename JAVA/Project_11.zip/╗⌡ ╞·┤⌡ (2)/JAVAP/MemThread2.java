package JAVAP;

import java.awt.Color;

import JAVAP.SwingProject_1.SwingProject1_newf;

public class MemThread2  implements Runnable{

	
	static Color red = new Color(255,184,249);   
	
	
	
	@Override
	public void run() {
	try {
		int l = 249 ;
		int j = 184;
		
		for (int i = 255; j<255; j++) {  //���ٲٸ鼭 ��� ���������ϱ� 
			if(SwingProject_2.mName.getText().equals(""))
				SwingProject_2.mName.setBackground(new Color(i,j,l));
			if(SwingProject_2.cho.getSelectedItem().equals("��� ����"))
				SwingProject_2.cho.setBackground(new Color(i,j,l));
			if(SwingProject_2.mPhone.getText().equals(""))
				SwingProject_2.mPhone.setBackground(new Color(i,j,l));
			Thread.sleep(20);
			if(l<255)
				l++;
		}
		}catch(Exception e){
			
		}

}}