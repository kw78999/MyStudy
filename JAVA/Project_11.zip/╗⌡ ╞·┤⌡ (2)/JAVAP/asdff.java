package JAVAP;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class asdff {
	//���������� �ѱ� ���� ����.
	 static  ImageIcon normalIcon1 = new ImageIcon("C:\\\\\\\\image\\\\ok.jpg"); 
	 static ImageIcon normalIcon2 = new ImageIcon("C:\\\\\\\\image\\\\ok2.jpg"); 
		 static  JButton okbtn ;
		 static  Image btnimg1 = normalIcon1.getImage(); 
		 static  Image btnimg2 = normalIcon2.getImage(); 
		 //��ư�� �̹��� �߰�
		 static   Image change1 = btnimg1.getScaledInstance(80, 45, Image.SCALE_SMOOTH);
		 static ImageIcon changeicon1 = new ImageIcon(change1);
		  
		 static   Image change2 = btnimg1.getScaledInstance(90, 50, Image.SCALE_SMOOTH);
		 static   ImageIcon changeicon2= new ImageIcon(change2);
		  
		 static  Image change3 = btnimg2.getScaledInstance(80, 45, Image.SCALE_SMOOTH);
		 static  ImageIcon changeicon3= new ImageIcon(change3);
		  ///////////////////////////////////////////////////////////
	
	static JFrame inputFrame = new JFrame();
	static JTextField tfTitle = new JTextField(25);
	static JTextField tfAuthor = new JTextField(25);
	static JLabel lab = new JLabel("�ѱ۷� �Է� ���ּ���");
	static JLabel lab2 = new JLabel("�� ��");
	static JLabel lab1 = new JLabel("�� ��");
	static Color bg = new Color(186,218,255);
	static JPanel panel = new JPanel();
	
	public asdff() {}
	
	
	
	
	public static void asd(String title,String author) {
		okbtn = new JButton(changeicon1);
		okbtn.setBorderPainted(false);			
		okbtn.setFocusPainted(false);
		okbtn.setContentAreaFilled(false);
		okbtn.addMouseListener(ok);
		
		lab.setFont(new Font(  "��Ǯ���¿��� Medium", Font.PLAIN, 18 ));
		lab1.setFont(new Font(  "��Ǯ���¿��� Medium", Font.PLAIN, 18 ));
		lab2.setFont(new Font(  "��Ǯ���¿��� Medium", Font.PLAIN, 18 ));
		if(getType(title)&&getType(author)) {//true�� ��ȯ�޾Ҵٸ� �ؼ��޼ҵ�
			JaMoSwitch.getTxt(title, author);
			//jamoswitch �żҵ� getTxt() ȣ��.
		}else {
			okbtn.addActionListener(btn1);
			
			
			inputFrame.setSize(400, 200);
			inputFrame.setLocationRelativeTo(null);
			panel.setLayout(null);
			panel.setBackground(bg);
			lab.setBounds(100, 10, 250, 30);
			lab1.setBounds(10, 50, 50, 30);
			lab2.setBounds(10, 90, 50, 30);
			tfTitle.setBounds(80, 50, 120, 24);
			tfAuthor.setBounds(80, 90, 120, 24);
			okbtn.setBounds(250, 60, 90, 50);
			panel.setBounds(0, 0, 400, 200);
			panel.add(tfTitle);
			panel.add(okbtn);
			panel.add(lab);
			panel.add(lab1);
			panel.add(lab2);
			panel.add(tfAuthor);
			inputFrame.add(panel);
			inputFrame.setVisible(true);
		}
	}
	//ù ������ Ÿ���� ��ȯ�ϴ� �޼ҵ�. �ѱ��̸� true �ƴϸ� false
	public static boolean getType(String word) {
        boolean korean = false;
            int index = word.charAt(0);
            if(index>=122) {
                korean = true;
            }
        return korean;
    }
	static ActionListener btn1 = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			if(tfTitle.getText().equals("")||tfAuthor.getText().equals("")) {
				Runnable tt = new BookThread4();
				Thread t1 = new Thread(tt);
				t1.start();
			}else {
			String str = tfTitle.getText();
			String str2 = tfAuthor.getText();
			asd(str,str2);
			inputFrame.dispose();
			}
		}
	};
	static MouseListener ok = new MouseListener() {
		
		@Override
		public void mouseReleased(MouseEvent e) {
			okbtn.setIcon(changeicon2);
		}
		@Override
		public void mousePressed(MouseEvent e) {
			okbtn.setIcon(changeicon3);
		}
		@Override
		public void mouseExited(MouseEvent e) {
			okbtn.setIcon(changeicon1);
		}
		@Override
		public void mouseEntered(MouseEvent e) {
			okbtn.setIcon(changeicon2);
		}
		@Override
		public void mouseClicked(MouseEvent e) {
		}
}; 
}