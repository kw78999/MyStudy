package JAVAP;

//������̹� : ���̺���+Bean
//���� : ���ڵ�(����) ������ ������ ���
public class LibStatBean {

	private String year;
	private String month;
	private String count;
	private String first;
	private String second;
	private String third;
	private String popCate;
	
	private int liter;
	private int history;
	private int social;
	private int phil;
	private int nsci;
	private int tsci;
	private int art;
	private int lang;
	private int reli;
	private int gene;
	
	private int maxCount;
	private int avgCnt;
	private int fstCnt;
	private int sndCnt;
	private int thdCnt;
	
	public int getLiter() {
		return liter;
	}
	public void setLiter(int liter) {
		this.liter = liter;
	}
	
	public int getHistory() {
		return history;
	}
	public void setHistory(int history) {
		this.history = history;
	}
	
	public int getSocial() {
		return social;
	}
	public void setSocial(int social) {
		this.social = social;
	}
	
	public int getPhil() {
		return phil;
	}
	public void setPhil(int phil) {
		this.phil = phil;
	}
	
	public int getNsci() {
		return nsci;
	}
	public void setNsci(int nsci) {
		this.nsci = nsci;
	}
	
	public int getTsci() {
		return tsci;
	}
	public void setTsci(int tsci) {
		this.tsci = tsci;
	}
	
	public int getArt() {
		return art;
	}
	public void setArt(int art) {
		this.art = art;
	}
	
	public int getLang() {
		return lang;
	}
	public void setLang(int lang) {
		this.lang = lang;
	}
	
	public int getReli() {
		return reli;
	}
	public void setReli(int reli) {
		this.reli = reli;
	}
	
	public int getGene() {
		return gene;
	}
	public void setGene(int gene) {
		this.gene = gene;
	}
	
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getCnt() {
		return count;
	}
	public void setCnt(String count) {
		this.count = count;
	}
	public String getMon() {
		return month;
	}
	public void setMon(String month) {
		this.month = month;
	}
	public String getFst() {
		return first;
	}
	public void setFst(String first) {
		this.first = first;
	}
	public String getSnd() {
		return second;
	}
	public void setSnd(String second) {
		this.second = second;
		}
	public String getThd() {
		return third;
	}
	public void setThd(String third) {
		this.third = third;
	}
	public String getPopCate() {
			return popCate;
		}
	public void setPopCate(String popCate) {
		this.popCate = popCate;
		}
	public int getMaxCount() {
		return maxCount;
	}
	public void setMaxCount(int maxCount) {
	this.maxCount = maxCount;
	}
	public int getAvgCnt() {
		return avgCnt;
	}
	public void setAvgCnt(int avgCnt) {
	this.avgCnt = avgCnt;
	}
	public int getFstCnt() {
		return fstCnt;
	}
	public void setFstCnt(int fstCnt) {
	this.fstCnt = fstCnt;
	}
	public int getSndCnt() {
		return sndCnt;
	}
	public void setSndCnt(int sndCnt) {
	this.sndCnt = sndCnt;
	}
	public int getThdCnt() {
		return thdCnt;
	}
	public void setThdCnt(int thdCnt) {
	this.thdCnt = thdCnt;
	}
	}
